package test;

public class Test {
    public static void main(String[] args) {
        Bank bank = new Bank();

        bank.Client("1111-1112","홍길동");

        bank.Balance(40000);
    }
}
